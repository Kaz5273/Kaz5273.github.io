package com.example.mygsbproject;

public class RecyclerViewAdapterInfo {
}
