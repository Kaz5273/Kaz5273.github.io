package com.example.mygsbproject;

import android.view.View;

public interface RecylcerviewClickListener {
    void onClick(View view, int position);
}
