package com.example.mygsbproject;

import com.google.gson.annotations.SerializedName;

public class Motifs {
    @SerializedName("id")
    private Integer id;
    @SerializedName("mot_libelle")
    private String mot_libelle;
    @SerializedName("mot_id")
    private Integer mot_id;
}
